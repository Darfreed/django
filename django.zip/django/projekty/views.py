from django.shortcuts import render
from django.utils import timezone
from .models import Project

def post_list(request):
    projects = Project.objects.filter(dokonceni__lte=timezone.now()).order_by('dokonceni')
    return render(request, 'projekty/index.html', {'projects': projects})
