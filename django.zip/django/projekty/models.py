from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
from django.urls import reverse

def attachments_path(instance, filename):
    return "projekty/" + str(instance.projekt.id) + "/attachments/" + filename

def img_path(instance, filename):
    return "projekty/" + str(instance.id) + "/img/" + filename

class Label(models.Model):
    nazev = models.CharField(max_length=50, unique=True, verbose_name="Název štítku",help_text='Napiš název štítku (hry, videa, atd.)')
    class Meta:
        ordering = ["nazev"]
    def __str__(self):
        return self.nazev

class Project(models.Model):
    nazev = models.CharField(max_length=200,verbose_name="Název")
    popis = models.TextField(blank=True, null=True, verbose_name="Popis")
    dokonceni = models.DateField(blank=True, null=True, verbose_name="Dokončení projektu")
    img = models.ImageField(upload_to=img_path, blank=True,null=True,verbose_name="Obrázek")
    stitky = models.ManyToManyField(Label, help_text='Vyber štítek projektu')
    class Meta:
        ordering = ["-dokonceni","nazev"]
    def __str__(self):
        return f"{self.nazev}, dokončen: {self.dokonceni.day}. {self.dokonceni.month}. {self.dokonceni.year}"
    def get_absolute_url(self):
        return reverse('detail-projektu', args=[str(self.id)])

class Attachment(models.Model):
    nazev = models.CharField(max_length=200,verbose_name="Název")
    posledni_zmena = models.DateTimeField(auto_now=True)
    file = models.FileField(upload_to=attachments_path,null=True,verbose_name="Soubor")
    TYPE_OF_ATTACHMENTS = (
        ('audio', 'Audio'),
        ('image', 'Image'),
        ('text', 'Text'),
        ('video', 'Video'),
        ('other', 'Other'),
    )
    typ = models.CharField(max_length=5, choices=TYPE_OF_ATTACHMENTS, blank=True, default='image', help_text='Vyber typ souboru', verbose_name="Typ souboru")
    projekt = models.ForeignKey(Project, on_delete=models.CASCADE)
    class Meta:
        ordering = ["-posledni_zmena","typ"]
    def __str__(self):
        return f"{self.nazev} ({self.typ})"