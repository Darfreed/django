from django.contrib import admin
from .models import *

admin.site.register(Label)
admin.site.register(Project)
admin.site.register(Attachment)