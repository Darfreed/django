from django.apps import AppConfig


class ProjektyConfig(AppConfig):
    name = 'projekty'
